import { expect } from "chai";

describe("Test cases running", () => {
  it("Route test cases included", (done) => {
    expect(1 + 1).to.equal(2);
    done();
  });
});
