#!/bin/bash

sudo yum install unzip -y