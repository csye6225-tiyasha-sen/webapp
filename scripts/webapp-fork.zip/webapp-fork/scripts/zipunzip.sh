#!/bin/bash

mkdir webapp


unzip /tmp/webapp-fork.zip -d ~/webapp
cd ~/webapp/webapp-fork
npm install