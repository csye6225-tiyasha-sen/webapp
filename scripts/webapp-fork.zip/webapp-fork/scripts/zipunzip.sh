mkdir webapp

sudo cp /tmp/webapp.zip /home/webapp/webapp.zip

unzip webapp.zip -d ~/webapp/